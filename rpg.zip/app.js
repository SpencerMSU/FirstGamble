// Логика для обработки кнопок
document.getElementById("button1").addEventListener("click", function() {
    console.log("Кнопка 1 нажата");
    // Здесь можно будет сделать переход на страницу или открыть модальное окно
});

document.getElementById("button2").addEventListener("click", function() {
    console.log("Кнопка 2 нажата");
});

document.getElementById("button3").addEventListener("click", function() {
    console.log("Кнопка 3 нажата");
});

document.getElementById("button4").addEventListener("click", function() {
    console.log("Кнопка 4 нажата");
});app.get("/cabinet", (req,res) => res.sendFile(path.join(__dirname, "cabinet.html")));

